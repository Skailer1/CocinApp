package com.example.cocinerosapp.Presentador;

public interface BasePresentador {
}
