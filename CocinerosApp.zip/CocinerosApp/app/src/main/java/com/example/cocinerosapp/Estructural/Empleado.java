package com.example.cocinerosapp.Estructural;

public class Empleado {
}
