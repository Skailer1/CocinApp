package com.example.cocinerosapp.Estructural;

public class Pedido {
}
